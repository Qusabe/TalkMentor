package com.example.test;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.ResourceBundle;

public class MainMenu implements Initializable {
    @FXML
    private Label TalkMentor;

    @FXML
    private ProgressBar progressBar;
    @FXML
    private Button soundNwordB;

    @FXML
    private Button HardWordsB;

    @FXML
    private Button artikB;

    @FXML
    private Button b13;
    @FXML
    private  Button soglB;
    @FXML
    private  Button ttB;
    @FXML
    private  Button tcB;
    @FXML
    private  Button mixedB;
    @FXML
    private  Button sameWordB;
    @FXML
    private Button bangB;
    @FXML
    private  Button speedB;
    @FXML
    private Button bigAmB;
    @FXML
    private Button breathB;

    HashMap actName = new HashMap();



    @FXML
    private AnchorPane ANC1, ANC2, ANC3, ANC4, ANC5, ANC6, ANC7, ANC8, ANC9, ANC10, ANC11, ANC12, ANC13;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        setHoverEffect(ANC1);
        setHoverEffect(ANC2);
        setHoverEffect(ANC3);
        setHoverEffect(ANC4);
        setHoverEffect(ANC5);
        setHoverEffect(ANC6);
        setHoverEffect(ANC7);
        setHoverEffect(ANC8);
        setHoverEffect(ANC9);
        setHoverEffect(ANC10);
        setHoverEffect(ANC11);
        setHoverEffect(ANC12);
        setHoverEffect(ANC13);


        artikB.setOnAction(event -> {
            Parent root = null;
            try {
                root = FXMLLoader.load(getClass().getResource("TR6.fxml"));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
            System.out.println("Кнопка b13 нажата.");
        });

        breathB.setOnAction(event -> {
            Parent root = null;
            try {
                root = FXMLLoader.load(getClass().getResource("TR6.fxml"));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
            System.out.println("Кнопка b13 нажата.");
        });

        HardWordsB.setOnAction(event -> {
            Parent root = null;
            try {
                root = FXMLLoader.load(getClass().getResource("TR6.fxml"));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
            System.out.println("Кнопка b13 нажата.");
        });

        soundNwordB.setOnAction(event -> {
            Parent root = null;
            try {
                root = FXMLLoader.load(getClass().getResource("TR6.fxml"));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
            System.out.println("Кнопка b13 нажата.");
        });

        soglB.setOnAction(event -> {
            Parent root = null;
            try {
                root = FXMLLoader.load(getClass().getResource("TR6.fxml"));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
            System.out.println("Кнопка b13 нажата.");
        });

        ttB.setOnAction(event -> {  // +
            Parent root = null;
            try {
                root = FXMLLoader.load(getClass().getResource("TR6.fxml"));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
            System.out.println("Кнопка b13 нажата.");
        });

        bigAmB.setOnAction(event -> {
            Parent root = null;
            try {
                root = FXMLLoader.load(getClass().getResource("TR6.fxml"));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
            System.out.println("Кнопка b13 нажата.");
        });

        tcB.setOnAction(event -> {
            Parent root = null;
            try {
                root = FXMLLoader.load(getClass().getResource("TR6.fxml"));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
            System.out.println("Кнопка b13 нажата.");
        });

        mixedB.setOnAction(event -> {
            Parent root = null;
            try {
                root = FXMLLoader.load(getClass().getResource("TR6.fxml"));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
            System.out.println("Кнопка b13 нажата.");
        });

        sameWordB.setOnAction(event -> {
            Parent root = null;
            try {
                root = FXMLLoader.load(getClass().getResource("TR6.fxml"));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
            System.out.println("Кнопка b13 нажата.");
        });

        speedB.setOnAction(event -> {
            Parent root = null;
            try {
                root = FXMLLoader.load(getClass().getResource("TR6.fxml"));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
            System.out.println("Кнопка b13 нажата.");
        });

        bangB.setOnAction(event -> {
            Parent root = null;
            try {
                root = FXMLLoader.load(getClass().getResource("TR6.fxml"));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
            System.out.println("Кнопка b13 нажата.");
        });

        b13.setOnAction(event -> {
            Parent root = null;
            try {
                root = FXMLLoader.load(getClass().getResource("TR6.fxml"));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
            System.out.println("Кнопка b13 нажата.");
        });
    }


    private void setHoverEffect(AnchorPane anchorPane) {
        DropShadow dropShadow = new DropShadow();
        dropShadow.setHeight(40.0);
        dropShadow.setRadius(19.5);
        dropShadow.setSpread(0.7);
        dropShadow.setWidth(40.0);
        anchorPane.setEffect(dropShadow);

        anchorPane.setOnMouseEntered(event -> {
            // Изменение прозрачности при наведении курсора мыши
            anchorPane.setOpacity(0.8);
        });

        anchorPane.setOnMouseExited(event -> {
            // Возвращение прозрачности после выхода курсора мыши
            anchorPane.setOpacity(0.6);
        });
    }

//    private static void progressUserExercises(String mail, String progress) throws SQLException {
//        DatabaseHandler dbHandler = new DatabaseHandler();
//        String progressExercises = dbHandler.getProgressExercises(mail);
//        if (progressExercises.indexOf(progress)==-1){
//            System.out.println("Такой подстроки нет");
//            dbHandler.progressUserExercises(mail, progress);
//        }
//        else
//            System.out.println("Такая подстрока есть");
//    }

}


